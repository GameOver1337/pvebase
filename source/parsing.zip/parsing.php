<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Получение информации о персонаже</title>
    <style>
        body {
            background-color: #1f1f1f; /* Цвет фона */
            color: #fff; /* Цвет текста */
            font-family: Arial, sans-serif; /* Шрифт */
            padding: 20px; /* Отступы вокруг содержимого */
        }

        /* Стили для текста внутри span */
        span {
            display: block; /* Начать текст с новой строки */
        }

        /* Дополнительные стили для span с разными цветами */
        span[color="#0f0"] {
            color: #0f0; /* Зеленый цвет текста */
        }

        span[color="#c0c0c0"] {
            color: #c0c0c0; /* Серый цвет текста */
        }

        /* Стили для ссылок */
        a {
            color: #0099ff; /* Цвет ссылок */
        }

        a:hover {
            color: #00ccff; /* Цвет ссылок при наведении */
        }

        /* Стили для кастомной подсказки */
        .custom_tooltip {
            display: block;
            /* border-bottom: 1px dotted #fff; */
            color: #fff;
        }

        .custom_tooltip .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: #1f1f1f;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: relative; /* Изменено с absolute на relative */
            z-index: 1;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .custom_tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }
        
        /* Стили для dungeon_name */
        .dungeon_name {
            font-weight: bold;
            font-size: 16px;
            color: #0099ff; /* Цвет названия подземелья */
            margin-bottom: 5px;
        }

        /* Стили для progress бара */
        .progress {
            height: 20px;
            background-color: #333;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 10px;
        }

        .progress .progress-bar {
            height: 100%;
            background-color: #c0c0c0; /* Цвет progress бара по умолчанию */
            transition: width 0.5s ease-in-out; /* Плавное изменение ширины */
        }
    </style>
</head>
<body>

<div id="raidContainer">
    <?php
    // Включаем библиотеку для парсинга HTML
    include('simple_html_dom.php');

    function getPlayerInfo()
    {
        // Отправляем запрос на внешний сервер с использованием cURL, user-agent и куков
        $url = "https://cp.pandawow.me/armory/char-10-120.html";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);

        // Используем файл для хранения и отправки куков
        curl_setopt($ch, CURLOPT_COOKIEJAR, getCookieFile());
        curl_setopt($ch, CURLOPT_COOKIEFILE, getCookieFile());

        // Задержка перед запросом
        delayRequest();

        $response = curl_exec($ch);

        // Проверяем на ошибки выполнения запроса
        if (curl_errno($ch)) {
            $errorMessage = curl_error($ch);
            error_log("cURL Error: $errorMessage");
            return false; // Возвращаем false в случае ошибки
        }

        // Закрываем cURL соединение
        curl_close($ch);

        // Парсим HTML с помощью Simple HTML DOM Parser
        $html = str_get_html($response);
        $raidContainer = $html->find('div[class=raid_frame]', 0); // Находим первый элемент с классом 'raid_frame'

        // Удаляем из контейнера все изображения
        foreach ($raidContainer->find('img') as $image) {
            $image->outertext = '';
        }

        // Удаляем из контейнера все элементы span с классом 'difficulty_name'
        foreach ($raidContainer->find('span.difficulty_name') as $span) {
            $span->outertext = '';
        }

        // Удаляем из контейнера все элементы span с классом 'raid_title'
        foreach ($raidContainer->find('span.raid_title') as $span) {
            $span->outertext = '';
        }

        // Выводим содержимое элемента 'raid_container' без изображений и указанных span
        if ($raidContainer) {
            echo $raidContainer->innertext; // Выводим содержимое элемента
        } else {
            echo "Не удалось найти контейнер рейда."; // Выводим сообщение об ошибке, если контейнер не найден
        }
    }

    // Функция для получения уникального файла куков
    function getCookieFile()
    {
        return sys_get_temp_dir() . '/cookie.txt';
    }

    // Функция для задержки перед запросом (можно настроить в соответствии с требованиями сайта)
    function delayRequest()
    {
        // Например, делаем задержку на 1 секунды
        sleep(1);
    }

    // Вызываем функцию для получения и вывода информации о игроке
    getPlayerInfo();
    ?>
</div>
</body>
</html>
